module.exports = {
  host: 'aws-mysql-canvas.cqaxkdwv7tze.us-west-2.rds.amazonaws.com',
  user: 'admin',
  password: 'Year2021!',
  database: 'AttendanceTracking'
};
